#ifndef __ADC_H
#define __ADC_H 
#include "stm32f10x.h"
void  ADC2_Init(void);    //ADC3��ʼ��//
u16 Get_ADC2(u8 ch) ;
#endif 


