#ifndef _KEY_H
#define _KEY_H
#define KEY1 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6)
#define KEY2 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7)
void key_init_(void);//��������
void key_scan(void);
#endif
