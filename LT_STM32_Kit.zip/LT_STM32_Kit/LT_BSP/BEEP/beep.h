
#ifndef __BEEP_H
#define __BEEP_H	 
#include "sys.h"
void BEEP_Init(void);//��ʼ��		
void beep_play(void);
#endif




