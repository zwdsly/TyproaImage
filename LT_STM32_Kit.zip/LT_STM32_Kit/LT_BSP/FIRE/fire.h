#ifndef _FIRE_H
#define _FIRE_H
#define fire_read  GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0)
void fire_init(void);
#endif



